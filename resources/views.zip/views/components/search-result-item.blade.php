{{-- Individual Search Result Item --}}
<div class="col-12 mb-4">
    <div class="card border-0 shadow-sm h-100">
        <div class="row g-0">
            <!-- Result Image -->
            <div class="col-md-4">
                <img src="{{ $result['image'] }}" 
                     class="img-fluid rounded-start h-100" 
                     style="object-fit: cover;"
                     alt="{{ $result['title'] }}">
            </div>
            
            <!-- Result Details -->
            <div class="col-md-8">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <h5 class="card-title mb-1">{{ $result['title'] }}</h5>
                            <p class="text-muted small mb-2">
                                <i class="fas fa-map-marker-alt text-danger me-1"></i>
                                {{ $result['location'] }}
                            </p>
                        </div>
                        <div class="text-end">
                            <span class="badge bg-warning text-dark mb-2">
                                {{ $result['rating'] }} <i class="fas fa-star"></i>
                            </span>
                            <h4 class="text-primary mb-0">₹{{ $result['price'] }}</h4>
                            <small class="text-muted">per night</small>
                        </div>
                    </div>
                    
                    <p class="card-text mt-3">{{ $result['description'] }}</p>
                    
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <div class="amenities">
                            @foreach($result['amenities'] as $amenity)
                                <span class="badge bg-light text-dark me-1">
                                    <i class="fas fa-{{ $amenity['icon'] }} me-1"></i>
                                    {{ $amenity['name'] }}
                                </span>
                            @endforeach
                        </div>
                        <a href="{{ $result['url'] }}" class="btn btn-primary">
                            <i class="fas fa-eye me-1"></i> View Details
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>