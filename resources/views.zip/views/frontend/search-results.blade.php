@extends('layouts.app')

@section('title', 'Search Results - Travel Explorer')

@section('content')
    <!-- Search Results Header -->
    <div class="container py-5">
        <div class="row mb-4">
            <div class="col-12">
                <h1 class="mb-3">
                    <i class="fas fa-search me-2 text-primary"></i>Search Results
                </h1>
                
                <!-- Search Summary -->
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-md-8">
                                <p class="mb-2">
                                    <strong>Search For:</strong> 
                                    <span class="text-primary">{{ $searchParams['location'] ?? 'All Destinations' }}</span>
                                </p>
                                <div class="d-flex flex-wrap gap-2">
                                    @foreach($activeFilters as $filter)
                                        <span class="badge bg-primary">
                                            {{ $filter }}
                                            <button type="button" class="btn-close btn-close-white ms-2" style="font-size: 0.6rem;"></button>
                                        </span>
                                    @endforeach
                                </div>
                            </div>
                            <div class="col-md-4 text-md-end">
                                <div class="dropdown">
                                    <button class="btn btn-outline-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                        <i class="fas fa-sliders-h me-2"></i>Modify Search
                                    </button>
                                    <div class="dropdown-menu p-3" style="min-width: 300px;">
                                        <!-- Insert Advanced Search Form Here -->
                                        @include('components.advanced-search')
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Results Content -->
        <div class="row">
            <!-- Sidebar Filters -->
            <div class="col-lg-3 mb-4">
                <div class="sticky-top" style="top: 100px;">
                    <!-- Quick Filter Sidebar -->
                    @include('components.search-sidebar')
                </div>
            </div>

            <!-- Results List -->
            <div class="col-lg-9">
                <!-- Results Count and Sorting -->
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <p class="mb-0">
                        <strong>{{ $totalResults }}</strong> results found
                        <span class="text-muted">(Showing {{ $results->count() }})</span>
                    </p>
                    <select class="form-select w-auto">
                        <option>Sort by: Relevance</option>
                        <option>Price: Low to High</option>
                        <option>Price: High to Low</option>
                        <option>Rating</option>
                        <option>Distance</option>
                    </select>
                </div>

                <!-- Results Grid -->
                <div class="row" id="searchResults">
                    <!-- Results will be loaded here -->
                    @foreach($results as $result)
                        @include('components.search-result-item', ['result' => $result])
                    @endforeach
                </div>

                <!-- Pagination -->
                <div class="d-flex justify-content-center mt-5">
                    {{ $results->links() }}
                </div>
            </div>
        </div>
    </div>
@endsection