@extends('layouts.app')

@section('title', 'Travel Explorer - Find Your Perfect Destination')

@section('content')
    <!-- Hero Section -->
    <section class="hero-section" style="padding-top: 180px; padding-bottom: 80px; background: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), url('https://images.unsplash.com/photo-1488646953014-85cb44e25828?ixlib=rb-4.0.3&auto=format&fit=crop&w=1350&q=80') center/cover no-repeat;">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mx-auto text-center text-white">
                    <h1 class="display-4 fw-bold mb-4 animate__animated animate__fadeInDown">
                        Discover Amazing Travel Destinations
                    </h1>
                    <p class="lead mb-5 animate__animated animate__fadeInUp animate__delay-1s">
                        Explore the world's most beautiful places, find perfect accommodations, and create unforgettable memories with our travel platform.
                    </p>
                    <div class="d-flex flex-wrap justify-content-center gap-3 animate__animated animate__fadeInUp animate__delay-2s">
                        <a href="#destinations" class="btn btn-primary btn-lg px-5">
                            <i class="fas fa-map-marked-alt me-2"></i>Explore Destinations
                        </a>
                        <a href="#hotels" class="btn btn-outline-light btn-lg px-5">
                            <i class="fas fa-hotel me-2"></i>Find Hotels
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Search Filters Section -->
    <div class="container my-5">
        @include('components.advanced-search')
    </div>

    <!-- Featured Destinations -->
    <section id="destinations" class="section-padding bg-light">
        <div class="container">
            <div class="section-title">
                <h2>Featured Destinations</h2>
                <p>Discover our handpicked collection of amazing travel destinations</p>
            </div>

            <!-- Search Filters -->
            <div class="row mb-5">
                <div class="col-md-8 mx-auto">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <div class="row g-3">
                                <div class="col-md-4">
                                    <select class="form-select">
                                        <option value="">Select State</option>
                                        <option value="assam">Assam</option>
                                        <option value="goa">Goa</option>
                                        <option value="kerala">Kerala</option>
                                        <option value="rajasthan">Rajasthan</option>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <select class="form-select">
                                        <option value="">Select Category</option>
                                        <option value="hill">Hill Station</option>
                                        <option value="beach">Beach</option>
                                        <option value="heritage">Heritage</option>
                                        <option value="wildlife">Wildlife</option>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <button class="btn btn-primary w-100">
                                        <i class="fas fa-filter me-2"></i>Filter
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Destinations Grid -->
            <div class="row" id="destinationsGrid">
                @for($i = 1; $i <= 9; $i++)
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="destination-card animate__animated animate__fadeInUp" style="animation-delay: {{ $i * 0.1 }}s;">
                            <div class="position-relative overflow-hidden">
                                <img src="https://images.unsplash.com/photo-{{ ['1552733407-5d5c46c3bb3b', '1520250497591-112f2f40a3f4', '1519681393784-d120267933ba', '1516483638261-f4dbaf036963', '1539635278303-d4002c07eae3', '1544551763-46a013bb70d5', '1506905925346-21bda4d32df4', '1533105079780-92b9be482077', '1519925610903-0cad6a038a4c'][$i-1] }}?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" 
                                     class="card-img-top" 
                                     alt="Destination {{ $i }}">
                                <div class="position-absolute top-0 end-0 m-3">
                                    <span class="badge bg-primary">
                                        <i class="fas fa-star me-1"></i>4.5
                                    </span>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <h5 class="card-title fw-bold">Destination {{ $i }}</h5>
                                    <span class="text-primary fw-bold">₹{{ rand(5000, 20000) }}</span>
                                </div>
                                <p class="card-text text-muted mb-3">
                                    <i class="fas fa-map-marker-alt text-danger me-1"></i>
                                    Location {{ $i }}, India
                                </p>
                                <p class="card-text mb-4">
                                    {{ 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam, voluptatum.' }}
                                </p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <a href="{{ url('/destination/' . $i) }}" class="btn btn-primary btn-sm">
                                        <i class="fas fa-eye me-1"></i>View Details
                                    </a>
                                    <div>
                                        <small class="text-muted">
                                            <i class="fas fa-hotel me-1"></i>
                                            {{ rand(10, 50) }} Hotels
                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                @endfor
            </div>

            <!-- View More Button -->
            <div class="text-center mt-5">
                <button class="btn btn-outline-primary btn-lg" id="loadMoreDestinations">
                    <i class="fas fa-plus me-2"></i>Load More Destinations
                </button>
            </div>
        </div>
    </section>

    <!-- Featured Hotels -->
    <section id="hotels" class="section-padding">
        <div class="container">
            <div class="section-title">
                <h2>Featured Hotels</h2>
                <p>Find the perfect accommodation for your stay</p>
            </div>

            <!-- Hotels Carousel (Owl Carousel) -->
            <div class="owl-carousel owl-theme">
                @for($i = 1; $i <= 6; $i++)
                    <div class="item">
                        <div class="card hotel-card border-0 shadow-sm">
                            <img src="https://images.unsplash.com/photo-{{ ['1566073771259-6a8506099945', '1551882547-ff3700d75d25', '1571896349842-3c7ad8e27b86', '1564501049412-61c2a3083791', '1520250497591-112f2f40a3f4', '1551632436-cbf8dd35ad39'][$i-1] }}?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" 
                                 class="card-img-top" 
                                 alt="Hotel {{ $i }}">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <h5 class="card-title fw-bold">Hotel {{ $i }}</h5>
                                    <span class="text-success fw-bold">
                                        <i class="fas fa-star text-warning"></i> {{ rand(3, 5) }}.0
                                    </span>
                                </div>
                                <p class="card-text text-muted mb-2">
                                    <i class="fas fa-map-marker-alt text-danger me-1"></i>
                                    Near Destination {{ $i }}
                                </p>
                                <div class="mb-3">
                                    @for($j = 0; $j < rand(1, 5); $j++)
                                        <span class="badge bg-light text-dark me-1 mb-1">
                                            {{ ['Free WiFi', 'Pool', 'Spa', 'Restaurant', 'Parking'][$j] }}
                                        </span>
                                    @endfor
                                </div>
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="h5 text-primary mb-0">₹{{ rand(1500, 8000) }}/night</span>
                                    <button class="btn btn-primary btn-sm">
                                        <i class="fas fa-bookmark me-1"></i>Book Now
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                @endfor
            </div>
        </div>
    </section>

    <!-- Travel Packages -->
    <section id="packages" class="section-padding bg-light">
        <div class="container">
            <div class="section-title">
                <h2>Travel Packages</h2>
                <p>All-inclusive packages for worry-free travel</p>
            </div>

            <!-- Packages Swiper -->
            <div class="swiper packages-swiper">
                <div class="swiper-wrapper">
                    @for($i = 1; $i <= 5; $i++)
                        <div class="swiper-slide">
                            <div class="card package-card border-0 shadow-lg h-100">
                                <div class="position-relative">
                                    <img src="https://images.unsplash.com/photo-{{ ['1552733407-5d5c46c3bb3b', '1520250497591-112f2f40a3f4', '1519681393784-d120267933ba', '1516483638261-f4dbaf036963', '1539635278303-d4002c07eae3'][$i-1] }}?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" 
                                         class="card-img-top" 
                                         alt="Package {{ $i }}">
                                    <div class="position-absolute top-0 start-0 m-3">
                                        <span class="badge bg-danger">-{{ rand(10, 30) }}%</span>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <h5 class="card-title fw-bold">Package {{ $i }} - {{ rand(3, 7) }} Days</h5>
                                    <p class="card-text text-muted mb-3">
                                        <i class="fas fa-map-marker-alt text-danger me-1"></i>
                                        Multiple Destinations
                                    </p>
                                    <ul class="list-unstyled mb-4">
                                        @for($j = 0; $j < 4; $j++)
                                            <li class="mb-2">
                                                <i class="fas fa-check text-success me-2"></i>
                                                {{ ['Hotel Accommodation', 'Breakfast Included', 'Sightseeing Tour', 'Transportation'][$j] }}
                                            </li>
                                        @endfor
                                    </ul>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <span class="text-decoration-line-through text-muted me-2">
                                                ₹{{ rand(20000, 40000) }}
                                            </span>
                                            <span class="h4 text-primary mb-0">
                                                ₹{{ rand(15000, 35000) }}
                                            </span>
                                        </div>
                                        <button class="btn btn-primary">
                                            <i class="fas fa-shopping-cart me-1"></i>Book Now
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endfor
                </div>
                <!-- Add Navigation -->
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
                <!-- Add Pagination -->
                <div class="swiper-pagination"></div>
            </div>
        </div>
    </section>

    <!-- Testimonials -->
    <section id="testimonials" class="section-padding">
        <div class="container">
            <div class="section-title">
                <h2>Traveler Testimonials</h2>
                <p>What our happy travelers say about us</p>
            </div>

            <!-- Slick Slider for Testimonials -->
            <div class="slick-slider testimonials-slider">
                @for($i = 1; $i <= 4; $i++)
                    <div class="testimonial-item p-4">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-body">
                                <div class="text-center mb-4">
                                    <img src="https://randomuser.me/api/portraits/{{ ['men', 'women'][$i % 2] }}/{{ $i + 20 }}.jpg" 
                                         class="rounded-circle mb-3" 
                                         alt="User {{ $i }}"
                                         width="80" 
                                         height="80">
                                    <h5 class="card-title mb-1">Traveler {{ $i }}</h5>
                                    <div class="text-warning mb-3">
                                        @for($j = 0; $j < 5; $j++)
                                            <i class="fas fa-star"></i>
                                        @endfor
                                    </div>
                                </div>
                                <p class="card-text text-muted">
                                    "{{ 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam, voluptatum. Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam, voluptatum.' }}"
                                </p>
                                <p class="text-end text-muted mt-3 mb-0">
                                    <small>
                                        Visited: {{ ['Guwahati', 'Goa', 'Kerala', 'Rajasthan'][$i-1] }}
                                    </small>
                                </p>
                            </div>
                        </div>
                    </div>
                @endfor
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="section-padding bg-dark text-white">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 mb-5 mb-lg-0">
                    <h2 class="fw-bold mb-4">Why Choose Travel Explorer?</h2>
                    <p class="lead mb-4">
                        We're committed to providing you with the best travel experience, from finding the perfect destination to booking your dream accommodation.
                    </p>
                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <div class="d-flex">
                                <div class="me-3">
                                    <i class="fas fa-shield-alt fa-2x text-primary"></i>
                                </div>
                                <div>
                                    <h5>Safe & Secure</h5>
                                    <p class="text-light">Secure bookings and verified partners</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-4">
                            <div class="d-flex">
                                <div class="me-3">
                                    <i class="fas fa-headset fa-2x text-primary"></i>
                                </div>
                                <div>
                                    <h5>24/7 Support</h5>
                                    <p class="text-light">Round-the-clock customer assistance</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-4">
                            <div class="d-flex">
                                <div class="me-3">
                                    <i class="fas fa-tags fa-2x text-primary"></i>
                                </div>
                                <div>
                                    <h5>Best Prices</h5>
                                    <p class="text-light">Guaranteed lowest prices</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-4">
                            <div class="d-flex">
                                <div class="me-3">
                                    <i class="fas fa-map-marked-alt fa-2x text-primary"></i>
                                </div>
                                <div>
                                    <h5>Wide Coverage</h5>
                                    <p class="text-light">Destinations across India</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="position-relative">
                        <img src="https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" 
                             class="img-fluid rounded shadow-lg" 
                             alt="About Us">
                        <div class="position-absolute bottom-0 start-0 bg-primary text-white p-4 m-3 rounded shadow">
                            <h4 class="mb-0">5000+</h4>
                            <p class="mb-0">Happy Travelers</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="section-padding">
        <div class="container">
            <div class="section-title">
                <h2>Contact Us</h2>
                <p>Get in touch with us for any queries or assistance</p>
            </div>
            
            <div class="row">
                <div class="col-lg-8 mx-auto">
                    <div class="card shadow-lg border-0">
                        <div class="card-body p-5">
                            <form id="contactForm">
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="name" class="form-label">Full Name</label>
                                            <input type="text" class="form-control" id="name" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="email" class="form-label">Email Address</label>
                                            <input type="email" class="form-control" id="email" required>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label for="subject" class="form-label">Subject</label>
                                            <input type="text" class="form-control" id="subject" required>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label for="message" class="form-label">Message</label>
                                            <textarea class="form-control" id="message" rows="5" required></textarea>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <button type="submit" class="btn btn-primary btn-lg w-100">
                                            <i class="fas fa-paper-plane me-2"></i>Send Message
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection

@section('scripts')
<script>
    // Load More Destinations
    document.getElementById('loadMoreDestinations').addEventListener('click', function() {
        const button = this;
        const destinationsGrid = document.getElementById('destinationsGrid');
        
        // Show loading
        button.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Loading...';
        button.disabled = true;
        
        // Simulate loading
        setTimeout(() => {
            // Add more destinations
            for(let i = 1; i <= 3; i++) {
                const newDestination = `
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="destination-card animate__animated animate__fadeInUp">
                            <div class="position-relative overflow-hidden">
                                <img src="https://images.unsplash.com/photo-${1506905925346 + i}?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" 
                                     class="card-img-top" 
                                     alt="New Destination ${i}">
                                <div class="position-absolute top-0 end-0 m-3">
                                    <span class="badge bg-primary">
                                        <i class="fas fa-star me-1"></i>4.${Math.floor(Math.random() * 9)}
                                    </span>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <h5 class="card-title fw-bold">New Destination ${i}</h5>
                                    <span class="text-primary fw-bold">₹${Math.floor(Math.random() * 15000) + 5000}</span>
                                </div>
                                <p class="card-text text-muted mb-3">
                                    <i class="fas fa-map-marker-alt text-danger me-1"></i>
                                    New Location ${i}, India
                                </p>
                                <p class="card-text mb-4">
                                    Discover this amazing new destination with us.
                                </p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <a href="/destination/new${i}" class="btn btn-primary btn-sm">
                                        <i class="fas fa-eye me-1"></i>View Details
                                    </a>
                                    <div>
                                        <small class="text-muted">
                                            <i class="fas fa-hotel me-1"></i>
                                            ${Math.floor(Math.random() * 40) + 10} Hotels
                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
                destinationsGrid.innerHTML += newDestination;
            }
            
            // Reset button
            button.innerHTML = '<i class="fas fa-plus me-2"></i>Load More Destinations';
            button.disabled = false;
            
            // Scroll to new destinations
            window.scrollTo({
                top: button.offsetTop - 100,
                behavior: 'smooth'
            });
        }, 1000);
    });
    
    // Contact Form Submission
    document.getElementById('contactForm')?.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get form data
        const formData = {
            name: document.getElementById('name').value,
            email: document.getElementById('email').value,
            subject: document.getElementById('subject').value,
            message: document.getElementById('message').value
        };
        
        // Show success message
        alert('Thank you for your message! We will get back to you soon.');
        this.reset();
    });
</script>
@endsection

<style>
    .hero-section {
        min-height: 100vh;
        display: flex;
        align-items: center;
    }
    
    .hero-section h1 {
        text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
    }
    
    .destination-card, .hotel-card, .package-card {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        height: 100%;
    }
    
    .destination-card:hover, .hotel-card:hover, .package-card:hover {
        transform: translateY(-10px);
        box-shadow: 0 15px 30px rgba(0,0,0,0.2) !important;
    }
    
    .owl-carousel .owl-item {
        padding: 15px;
    }
    
    .swiper {
        padding: 30px 10px 50px !important;
    }
    
    .swiper-slide {
        height: auto;
    }
    
    .slick-slider {
        margin: 0 -15px;
    }
    
    .slick-slide > div {
        padding: 0 15px;
    }
    
    .testimonial-item .card {
        height: 100%;
    }
    
    #about .position-relative img {
        filter: brightness(0.9);
    }
    
    .section-padding {
        padding: 80px 0;
    }
    
    @media (max-width: 768px) {
        .hero-section {
            padding-top: 120px;
            padding-bottom: 60px;
            min-height: auto;
        }
        
        .section-padding {
            padding: 60px 0;
        }
        
        .display-4 {
            font-size: 2.5rem;
        }
    }
</style>